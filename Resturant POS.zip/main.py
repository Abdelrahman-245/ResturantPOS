import json
from datetime import datetime



def load_data(file_name):
    try:
        with open(file_name, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

def save_data(file_name, data):
    with open(file_name, 'w') as file:
        json.dump(data, file, indent=4)


def create_menu_item(menu, name, price):
    menu[name] = {'price': price}

def create_order(orders, order_id, table_number):
    orders[order_id] = {
        'table_number': table_number,
        'items': [],
        'total': 0,
        'timestamp': datetime.now().isoformat()
    }

def add_item_to_order(orders, order_id, item_name, menu):
    if order_id in orders and item_name in menu:
        orders[order_id]['items'].append(item_name)
        orders[order_id]['total'] += menu[item_name]['price']


def display_menu(menu):
    print("--- Menu ---")
    for item, details in menu.items():
        print(f"{item}: ${details['price']:.2f}")

def display_order(order):
    print(f"Table {order['table_number']} | Total: ${order['total']:.2f}")
    print("Items:")
    for item in order['items']:
        print(f"- {item}")

def main():
    menu_file = 'menu.json'
    orders_file = 'orders.json'

    menu = load_data(menu_file)
    orders = load_data(orders_file)

    while True:
        print("\n--- Restaurant POS System ---")
        print("1. Add Menu Item")
        print("2. View Menu")
        print("3. Create Order")
        print("4. Add Item to Order")
        print("5. View Orders")
        print("6. Exit")

        choice = input("Choose an option: ").strip()

        if choice == '1':
            name = input("Enter item name: ").strip()
            price = float(input("Enter item price: ").strip())
            create_menu_item(menu, name, price)
            save_data(menu_file, menu)
            print(f"Added {name} to the menu.")

        elif choice == '2':
            display_menu(menu)

        elif choice == '3':
            order_id = input("Enter order ID: ").strip()
            table_number = input("Enter table number: ").strip()
            create_order(orders, order_id, table_number)
            save_data(orders_file, orders)
            print(f"Order {order_id} created for table {table_number}.")

        elif choice == '4':
            order_id = input("Enter order ID: ").strip()
            item_name = input("Enter item name: ").strip()
            if item_name in menu:
                add_item_to_order(orders, order_id, item_name, menu)
                save_data(orders_file, orders)
                print(f"Added {item_name} to order {order_id}.")
            else:
                print("Item not found in menu.")

        elif choice == '5':
            for order_id, order in orders.items():
                print(f"\nOrder ID: {order_id}")
                display_order(order)

        elif choice == '6':
            print("Exiting POS system.")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
